"""
Sistema de Detección de Movilidad Corporal
==========================================
Usa MediaPipe + OpenCV para detectar pose, calcular ángulos articulares
y guardar los resultados (video procesado + datos JSON).

Modos de uso:
  - Webcam en vivo (Linux con X11):  python main.py --source 0
  - Archivo de video (cualquier SO): python main.py --source /data/input/video.mp4
  - Headless (sin ventana):          python main.py --source /data/input/video.mp4 --headless

Salida:
  - Video procesado con esqueleto y ángulos en /data/output/
  - Datos JSON con todas las mediciones en /data/output/
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from core.pose_detector import PoseDetector
from core.angle_calculator import calculate_all_angles


def parse_args():
    parser = argparse.ArgumentParser(
        description="Detección de movilidad corporal con MediaPipe + OpenCV"
    )
    parser.add_argument(
        "--source",
        type=str,
        default="0",
        help="Fuente de video: 0 para webcam, o ruta a archivo de video (default: 0)",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Modo sin ventana (procesa y guarda sin mostrar)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="/data/output",
        help="Directorio de salida para videos y datos (default: /data/output)",
    )
    parser.add_argument(
        "--confidence",
        type=float,
        default=0.7,
        help="Confianza mínima de detección (default: 0.7)",
    )
    parser.add_argument(
        "--model",
        type=int,
        default=1,
        choices=[0, 1, 2],
        help="Complejidad del modelo: 0=lite, 1=full, 2=heavy (default: 1)",
    )
    parser.add_argument(
        "--max-frames",
        type=int,
        default=0,
        help="Máximo de frames a procesar (0 = sin límite, default: 0)",
    )
    return parser.parse_args()


def create_hud(frame: np.ndarray, angles: dict, fps: float, frame_num: int) -> np.ndarray:
    """
    Dibuja un HUD (heads-up display) con información del sistema
    en la parte superior e inferior del frame.
    """
    h, w, _ = frame.shape

    # === BARRA SUPERIOR ===
    # Fondo oscuro 
    cv2.rectangle(frame, (0, 0), (w, 45), (15, 15, 15), -1)

    # Línea de acento
    cv2.line(frame, (0, 45), (w, 45), (0, 200, 180), 1, cv2.LINE_AA)

    # Título
    cv2.putText(
        frame,
        "MOBILITY SCAN",
        (12, 18),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (0, 255, 220),
        1,
        cv2.LINE_AA,
    )

    # FPS
    fps_color = (0, 255, 100) if fps >= 20 else (0, 165, 255) if fps >= 10 else (0, 0, 255)
    cv2.putText(
        frame,
        f"FPS: {fps:.0f}",
        (w - 110, 18),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        fps_color,
        1,
        cv2.LINE_AA,
    )

    # Frame number
    cv2.putText(
        frame,
        f"Frame: {frame_num}",
        (w - 110, 36),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.4,
        (150, 150, 150),
        1,
        cv2.LINE_AA,
    )

    # Timestamp
    ts = datetime.now().strftime("%H:%M:%S")
    cv2.putText(
        frame,
        ts,
        (12, 36),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.4,
        (150, 150, 150),
        1,
        cv2.LINE_AA,
    )

    # === PANEL LATERAL DE ÁNGULOS ===
    if angles:
        panel_w = 220
        panel_x = w - panel_w - 10
        panel_y = 55
        line_h = 22
        visible_angles = {k: v for k, v in angles.items() if v["angle"] is not None}
        panel_h = len(visible_angles) * line_h + 30

        # Fondo del panel (sólido oscuro para mayor rendimiento)
        cv2.rectangle(
            frame,
            (panel_x, panel_y),
            (panel_x + panel_w, panel_y + panel_h),
            (20, 20, 20),
            -1,
        )
        cv2.rectangle(
            frame,
            (panel_x, panel_y),
            (panel_x + panel_w, panel_y + panel_h),
            (0, 200, 180),
            1,
            cv2.LINE_AA,
        )

        # Título del panel
        cv2.putText(
            frame,
            "ANGULOS",
            (panel_x + 8, panel_y + 18),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (0, 255, 220),
            1,
            cv2.LINE_AA,
        )

        # Listar ángulos
        y_offset = panel_y + 36
        for joint_key, data in visible_angles.items():
            status = data.get("status", "normal")
            if status == "normal":
                color = (0, 255, 100)
                indicator = "●"
            elif status == "limitado":
                color = (0, 165, 255)
                indicator = "▲"
            elif status == "excedido":
                color = (0, 0, 255)
                indicator = "■"
            else:
                color = (150, 150, 150)
                indicator = "○"

            name = data["name"]
            angle_val = data["angle"]

            cv2.putText(
                frame,
                f"{indicator} {name}",
                (panel_x + 8, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.38,
                (200, 200, 200),
                1,
                cv2.LINE_AA,
            )
            cv2.putText(
                frame,
                f"{angle_val:.0f} deg",
                (panel_x + panel_w - 70, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.38,
                color,
                1,
                cv2.LINE_AA,
            )

            y_offset += line_h

    # === BARRA INFERIOR (instrucciones) ===
    bottom_y = h - 30
    cv2.rectangle(frame, (0, bottom_y), (w, h), (15, 15, 15), -1)
    cv2.line(frame, (0, bottom_y), (w, bottom_y), (0, 200, 180), 1, cv2.LINE_AA)
    cv2.putText(
        frame,
        "Q: Salir  |  S: Captura  |  P: Pausar",
        (12, h - 10),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.4,
        (150, 150, 150),
        1,
        cv2.LINE_AA,
    )

    return frame


def main():
    args = parse_args()

    # Crear directorio de salida
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Determinar fuente de video
    if args.source.isdigit():
        source = int(args.source)
        source_name = f"webcam_{source}"
        print(f"[INFO] Usando webcam: /dev/video{source}")
    else:
        source = args.source
        source_name = Path(source).stem
        is_url = source.startswith(("http://", "https://", "rtsp://"))
        
        if not is_url and not os.path.exists(source):
            print(f"[ERROR] Archivo no encontrado: {source}")
            sys.exit(1)
            
        if is_url:
            print(f"[INFO] Procesando stream de red (celular/IP): {source}")
            source_name = "celular_stream"
        else:
            print(f"[INFO] Procesando video: {source}")

    # Abrir video
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"[ERROR] No se pudo abrir la fuente de video: {source}")
        print("[HINT] En macOS/Windows con Docker, usa --source con un archivo de video")
        print("[HINT] En Linux, asegúrate de pasar --device /dev/video0")
        sys.exit(1)

    # Propiedades del video
    frame_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps_source = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f"[INFO] Resolución: {frame_w}x{frame_h} @ {fps_source:.0f} FPS")
    if total_frames > 0:
        print(f"[INFO] Total frames: {total_frames}")

    # Inicializar detector
    print(f"[INFO] Inicializando MediaPipe (modelo={args.model}, confianza={args.confidence})")
    detector = PoseDetector(
        min_detection_confidence=args.confidence,
        model_complexity=args.model,
    )

    # Preparar escritor de video de salida
    session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_video_path = output_dir / f"sesion_{session_id}_{source_name}.mp4"
    output_data_path = output_dir / f"sesion_{session_id}_{source_name}_data.json"

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(
        str(output_video_path),
        fourcc,
        fps_source,
        (frame_w, frame_h),
    )

    print(f"[INFO] Video de salida: {output_video_path}")
    print(f"[INFO] Datos de salida: {output_data_path}")

    if not args.headless:
        print(f"[INFO] Modo visual activo — presiona Q para salir")
    else:
        print(f"[INFO] Modo headless — procesando sin ventana...")

    # Variables de sesión
    all_measurements = []
    frame_count = 0
    paused = False
    prev_time = time.time()
    fps_display = 0.0

    try:
        while cap.isOpened():
            if paused:
                key = cv2.waitKey(100) & 0xFF
                if key == ord("p"):
                    paused = False
                elif key == ord("q"):
                    break
                continue

            ret, frame = cap.read()
            if not ret:
                if isinstance(source, int):
                    print("[WARN] Frame perdido de la webcam, reintentando...")
                    continue
                else:
                    print("[INFO] Fin del video")
                    break

            frame_count += 1

            # Límite de frames
            if args.max_frames > 0 and frame_count > args.max_frames:
                print(f"[INFO] Límite de {args.max_frames} frames alcanzado")
                break

            # Calcular FPS real
            current_time = time.time()
            dt = current_time - prev_time
            if dt > 0:
                fps_display = 0.8 * fps_display + 0.2 * (1.0 / dt)
            prev_time = current_time

            # Detectar pose
            landmarks = detector.detect(frame)

            angles = {}
            if landmarks:
                # Calcular ángulos
                angles = calculate_all_angles(landmarks)

                # Guardar medición
                measurement = {
                    "frame": frame_count,
                    "timestamp": current_time,
                    "angles": {},
                }
                for joint_key, data in angles.items():
                    measurement["angles"][joint_key] = {
                        "angle": data["angle"],
                        "status": data["status"],
                        "visibility": data["visibility"],
                    }
                all_measurements.append(measurement)

                # Dibujar esqueleto
                frame = detector.draw_skeleton(frame, landmarks, angles)
            else:
                # Sin detección — indicador visual
                cv2.putText(
                    frame,
                    "SIN DETECCION",
                    (frame_w // 2 - 100, frame_h // 2),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 0, 255),
                    2,
                    cv2.LINE_AA,
                )

            # Dibujar HUD
            frame = create_hud(frame, angles, fps_display, frame_count)

            # Escribir frame al video de salida
            writer.write(frame)

            # Mostrar ventana si no es headless
            if not args.headless:
                cv2.imshow("Mobility Scan - MediaPipe + OpenCV", frame)

                key = cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    print("[INFO] Salida solicitada por usuario")
                    break
                elif key == ord("s"):
                    # Captura de pantalla
                    screenshot_path = output_dir / f"captura_{session_id}_f{frame_count}.png"
                    cv2.imwrite(str(screenshot_path), frame)
                    print(f"[INFO] Captura guardada: {screenshot_path}")
                elif key == ord("p"):
                    paused = True
                    print("[INFO] Pausado — presiona P para continuar")

            # Progreso para archivos de video
            if total_frames > 0 and frame_count % 100 == 0:
                progress = (frame_count / total_frames) * 100
                print(f"[INFO] Progreso: {progress:.1f}% ({frame_count}/{total_frames})")

    except KeyboardInterrupt:
        print("\n[INFO] Interrumpido por el usuario")

    finally:
        # Guardar datos JSON
        session_data = {
            "session_id": session_id,
            "source": str(source),
            "resolution": f"{frame_w}x{frame_h}",
            "fps": fps_source,
            "total_frames_processed": frame_count,
            "model_complexity": args.model,
            "detection_confidence": args.confidence,
            "measurements": all_measurements,
            "summary": generate_summary(all_measurements),
        }

        with open(output_data_path, "w", encoding="utf-8") as f:
            json.dump(session_data, f, indent=2, ensure_ascii=False, default=str)

        # Liberar recursos
        cap.release()
        writer.release()
        detector.release()
        if not args.headless:
            cv2.destroyAllWindows()

        print(f"\n{'='*50}")
        print(f"  SESIÓN COMPLETADA")
        print(f"{'='*50}")
        print(f"  Frames procesados: {frame_count}")
        print(f"  Video guardado:    {output_video_path}")
        print(f"  Datos guardados:   {output_data_path}")
        print(f"{'='*50}")

        # Mostrar resumen de ángulos
        if all_measurements:
            summary = session_data["summary"]
            print(f"\n  RESUMEN DE ÁNGULOS (promedios)")
            print(f"  {'─'*40}")
            for joint_key, stats in summary.items():
                print(
                    f"  {stats['name']:16s}  "
                    f"min={stats['min']:5.1f}°  "
                    f"max={stats['max']:5.1f}°  "
                    f"avg={stats['avg']:5.1f}°"
                )
            print()


def generate_summary(measurements: list) -> dict:
    """Genera un resumen estadístico de todas las mediciones de la sesión."""
    if not measurements:
        return {}

    # Agrupar ángulos por articulación
    angle_data = {}
    for m in measurements:
        for joint_key, data in m["angles"].items():
            if data["angle"] is not None:
                if joint_key not in angle_data:
                    angle_data[joint_key] = {
                        "name": data.get("name", joint_key),
                        "values": [],
                    }
                angle_data[joint_key]["values"].append(data["angle"])

    # Calcular estadísticas
    summary = {}
    for joint_key, data in angle_data.items():
        values = data["values"]
        if values:
            # Obtener el nombre desde los datos
            name = joint_key
            for m in measurements:
                if joint_key in m["angles"] and "name" in m["angles"][joint_key]:
                    name = m["angles"][joint_key].get("name", joint_key)
                    break

            summary[joint_key] = {
                "name": name,
                "min": round(min(values), 1),
                "max": round(max(values), 1),
                "avg": round(sum(values) / len(values), 1),
                "std": round(float(np.std(values)), 1),
                "samples": len(values),
            }

    return summary


if __name__ == "__main__":
    main()
