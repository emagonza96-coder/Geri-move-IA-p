"""
Detector de pose corporal usando MediaPipe Tasks API (PoseLandmarker).
API moderna que reemplaza la legacy mp.solutions.pose.
"""

import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from typing import Optional, List, Dict
import os
import urllib.request


MODEL_URLS = {
    0: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
    1: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task",
    2: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task",
}

def ensure_model(model_complexity: int = 1) -> str:
    """Descarga el modelo si no existe localmente y retorna la ruta."""
    model_name = ["lite", "full", "heavy"][model_complexity]
    model_filename = f"pose_landmarker_{model_name}.task"
    model_path = os.path.join(os.path.dirname(__file__), "..", "models", model_filename)
    
    model_dir = os.path.dirname(model_path)
    os.makedirs(model_dir, exist_ok=True)

    if not os.path.exists(model_path):
        print(f"[INFO] Descargando modelo PoseLandmarker {model_name}...")
        url = MODEL_URLS.get(model_complexity, MODEL_URLS[1])
        urllib.request.urlretrieve(url, model_path)
        print(f"[INFO] Modelo descargado en: {model_path}")
        
    return model_path


class PoseDetector:
    """Detector de pose humana usando MediaPipe Tasks PoseLandmarker."""

    # Conexiones del esqueleto para dibujar
    SKELETON_CONNECTIONS = [
        # Torso
        (11, 12), (11, 23), (12, 24), (23, 24),
        # Brazo izquierdo
        (11, 13), (13, 15),
        # Brazo derecho
        (12, 14), (14, 16),
        # Pierna izquierda
        (23, 25), (25, 27),
        # Pierna derecha
        (24, 26), (26, 28),
        # Manos (simplificado)
        (15, 17), (15, 19),
        (16, 18), (16, 20),
        # Pies
        (27, 29), (27, 31),
        (28, 30), (28, 32),
    ]

    # Nombres de landmarks principales
    LANDMARK_NAMES = {
        0: "nariz",
        11: "hombro_izq", 12: "hombro_der",
        13: "codo_izq", 14: "codo_der",
        15: "muneca_izq", 16: "muneca_der",
        23: "cadera_izq", 24: "cadera_der",
        25: "rodilla_izq", 26: "rodilla_der",
        27: "tobillo_izq", 28: "tobillo_der",
    }

    def __init__(
        self,
        min_detection_confidence: float = 0.7,
        min_tracking_confidence: float = 0.5,
        model_complexity: int = 1,
    ):
        """
        Inicializa el detector de pose con MediaPipe Tasks API.

        Args:
            min_detection_confidence: Confianza mínima para detección (0.0-1.0)
            min_tracking_confidence: Confianza mínima para tracking (0.0-1.0)
            model_complexity: 0=lite, 1=full, 2=heavy
        """
        # Descargar modelo si no existe
        model_path = ensure_model(model_complexity)

        # Configurar PoseLandmarker en modo VIDEO
        base_options = python.BaseOptions(model_asset_path=model_path)
        options = vision.PoseLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.VIDEO,
            min_pose_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
            num_poses=1,
        )
        self.detector = vision.PoseLandmarker.create_from_options(options)
        self._frame_timestamp_ms = 0

    def detect(self, frame: np.ndarray) -> Optional[List[Dict]]:
        """
        Detecta pose en un frame BGR de OpenCV.

        Args:
            frame: Frame BGR de OpenCV (numpy array)

        Returns:
            Lista de landmarks con x, y, z, visibility o None si no se detecta pose
        """
        # Convertir BGR → RGB para MediaPipe
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

        # Incrementar timestamp (MediaPipe Tasks requiere timestamps crecientes)
        self._frame_timestamp_ms += 33  # ~30 FPS

        # Detectar
        result = self.detector.detect_for_video(mp_image, self._frame_timestamp_ms)

        if not result.pose_landmarks or len(result.pose_landmarks) == 0:
            return None

        # Convertir al formato que usa el resto del sistema
        landmarks = []
        for lm in result.pose_landmarks[0]:  # Primera persona detectada
            landmarks.append({
                "x": lm.x,
                "y": lm.y,
                "z": lm.z,
                "visibility": lm.visibility,
            })

        return landmarks

    def draw_skeleton(
        self,
        frame: np.ndarray,
        landmarks: List[Dict],
        angles: Optional[Dict] = None,
    ) -> np.ndarray:
        """
        Dibuja el esqueleto y ángulos sobre el frame de forma directa y rápida.

        Args:
            frame: Frame BGR sobre el cual dibujar
            landmarks: Lista de landmarks detectados
            angles: Diccionario de ángulos calculados (opcional)

        Returns:
            Frame con el esqueleto dibujado
        """
        h, w, _ = frame.shape

        # Dibujar conexiones del esqueleto sin overlay de frame completo
        for conn in self.SKELETON_CONNECTIONS:
            idx_a, idx_b = conn
            lm_a = landmarks[idx_a]
            lm_b = landmarks[idx_b]

            # Solo dibujar si ambos son visibles
            if lm_a["visibility"] < 0.5 or lm_b["visibility"] < 0.5:
                continue

            pt_a = (int(lm_a["x"] * w), int(lm_a["y"] * h))
            pt_b = (int(lm_b["x"] * w), int(lm_b["y"] * h))

            # Dibujo directo simple para mayor rendimiento
            cv2.line(frame, pt_a, pt_b, (0, 255, 200), 2, cv2.LINE_AA)

        # Dibujar puntos de landmarks principales
        for idx, name in self.LANDMARK_NAMES.items():
            lm = landmarks[idx]
            if lm["visibility"] < 0.5:
                continue

            pt = (int(lm["x"] * w), int(lm["y"] * h))

            # Punto simple
            cv2.circle(frame, pt, 4, (0, 255, 255), -1, cv2.LINE_AA)

        # Dibujar ángulos si están disponibles
        if angles:
            self._draw_angles(frame, landmarks, angles, w, h)

        return frame

    def _draw_angles(
        self,
        frame: np.ndarray,
        landmarks: List[Dict],
        angles: Dict,
        w: int,
        h: int,
    ):
        """Dibuja los ángulos calculados sobre las articulaciones."""
        # Mapeo de articulación a landmark del vértice (donde se muestra el ángulo)
        vertex_map = {
            "hombro_izq": 11,
            "codo_izq": 13,
            "cadera_izq": 23,
            "rodilla_izq": 25,
            "hombro_der": 12,
            "codo_der": 14,
            "cadera_der": 24,
            "rodilla_der": 26,
        }

        for joint_key, data in angles.items():
            if data["angle"] is None:
                continue

            vertex_idx = vertex_map.get(joint_key)
            if vertex_idx is None:
                continue

            lm = landmarks[vertex_idx]
            if lm["visibility"] < 0.5:
                continue

            pt = (int(lm["x"] * w), int(lm["y"] * h))

            # Color según estado
            status = data.get("status", "normal")
            if status == "normal":
                color = (0, 255, 100)  # Verde
            elif status == "limitado":
                color = (0, 165, 255)  # Naranja
            elif status == "excedido":
                color = (0, 0, 255)  # Rojo
            else:
                color = (200, 200, 200)  # Gris

            angle_text = f"{data['angle']:.0f} deg"

            # Fondo semi-transparente para el texto
            (text_w, text_h), _ = cv2.getTextSize(
                angle_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            offset_x = 12
            offset_y = -8

            bg_pt1 = (pt[0] + offset_x - 2, pt[1] + offset_y - text_h - 4)
            bg_pt2 = (pt[0] + offset_x + text_w + 4, pt[1] + offset_y + 4)
            cv2.rectangle(frame, bg_pt1, bg_pt2, (30, 30, 30), -1, cv2.LINE_AA)
            cv2.rectangle(frame, bg_pt1, bg_pt2, color, 1, cv2.LINE_AA)

            cv2.putText(
                frame,
                angle_text,
                (pt[0] + offset_x, pt[1] + offset_y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                color,
                1,
                cv2.LINE_AA,
            )

    def release(self):
        """Libera recursos de MediaPipe."""
        self.detector.close()
